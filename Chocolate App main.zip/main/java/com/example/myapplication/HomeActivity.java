package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button darkButton = findViewById(R.id.dark_chocolate_button);
        Button milkButton = findViewById(R.id.milk_chocolate_button);
        Button whiteButton = findViewById(R.id.white_chocolate_button);

        darkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openChocolateInfoActivity("Dark Chocolate");
            }
        });

        milkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openChocolateInfoActivity("Milk Chocolate");
            }
        });

        whiteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openChocolateInfoActivity("White Chocolate");
            }
        });
    }

    private void openChocolateInfoActivity(String chocolateType) {
        Intent intent = new Intent(this, ChocolateInfoActivity.class);
        intent.putExtra("CHOCOLATE_TYPE", chocolateType);
        startActivity(intent);
    }
}
