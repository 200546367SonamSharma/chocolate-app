package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ChocolateInfoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chocolate_info);

        ImageView imageView = findViewById(R.id.chocolate_image);
        TextView textView = findViewById(R.id.chocolate_text);
        Button backButton = findViewById(R.id.back_button);

        String chocolateType = getIntent().getStringExtra("CHOCOLATE_TYPE");

        if ("Dark Chocolate".equals(chocolateType)) {
            imageView.setImageResource(R.drawable.dark);
            textView.setText(R.string.dark_chocolate_info);
        } else if ("Milk Chocolate".equals(chocolateType)) {
            imageView.setImageResource(R.drawable.milk);
            textView.setText(R.string.milk_chocolate_info);
        } else if ("White Chocolate".equals(chocolateType)) {
            imageView.setImageResource(R.drawable.white);
            textView.setText(R.string.white_chocolate_info);
        }

        // Set the back button click listener
        backButton.setOnClickListener(v -> {
            finish(); // Close the current activity and go back
        });
    }
}
